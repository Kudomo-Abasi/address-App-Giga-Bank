// Define the light theme
import 'package:flutter/material.dart';

final appThemeData = ThemeData(
  scaffoldBackgroundColor: Colors.white,
  brightness: Brightness.light,
  colorSchemeSeed: Colors.deepPurple.shade800,
  // useMaterial3: true,

  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      foregroundColor: Colors.white,
      backgroundColor: Colors.deepPurple.shade400, // Set the text color
    ),
  ),
  outlinedButtonTheme: OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
      foregroundColor: Colors.purple,
      side: const BorderSide(color: Colors.purple), // Set the border color
    ),
  ),
  buttonTheme: ButtonThemeData(
    minWidth: 200,
    height: 50,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(8), // Set your desired border radius
    ),
  ),
);
