import 'package:flutter/material.dart';

class DrawerContent extends StatefulWidget {
  const DrawerContent({super.key});

  @override
  State<DrawerContent> createState() => _DrawerContentState();
}

class _DrawerContentState extends State<DrawerContent> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            color: Theme.of(context).primaryColor,
            child: const Row(
              children: [
                CircleAvatar(
                  foregroundImage: AssetImage('/images/kudomoabasiekpo.jpg'),
                ),
                SizedBox(
                  width: 15,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Kudomo-Abasi Akpan Ekpo',
                      style: TextStyle(color: Colors.white),
                    ),
                    Text('kuyana57@gmail.com',
                        style: TextStyle(color: Colors.white)),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              '"It would be great to work for your organization"',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ),
        ],
      ),
    );
  }
}
