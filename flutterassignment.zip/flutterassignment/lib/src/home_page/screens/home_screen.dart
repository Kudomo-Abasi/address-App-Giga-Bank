import 'package:flutter/material.dart';
import 'package:flutterassignment/src/address_page/models/address_class.dart';
import 'package:flutterassignment/src/home_page/screens/widgets/drawer_content.dart';
import 'package:get/get.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.title});

  final String title;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    addressList.listen((p0) {
      if (mounted) setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: const Drawer(
          child: DrawerContent(),
        ),
        appBar: AppBar(
          title: Text(widget.title),
        ),
        body: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(
                      height: 15,
                    ),
                    ElevatedButton(
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.all(16.0),
                        textStyle: const TextStyle(fontSize: 20),
                        backgroundColor: Colors.blue,
                        elevation: 5,
                      ),
                      onPressed: () {
                        Get.toNamed('/add-address');
                      },
                      child: const Text('Add address',
                          style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              ),
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (BuildContext context, int index) {
                  AddressFormData address = addressList[index];
                  return GestureDetector(
                    onTap: () {
                      Get.toNamed('/add-address',
                          arguments: addressList[index]);
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: ListTile(
                        title: Text(
                          'Country: ${address.country}',
                          style: Theme.of(context).textTheme.bodyLarge,
                        ),
                        subtitle: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Row(
                              children: [
                                OutlinedContainer(
                                  child: Text(address.prefecture),
                                ),
                                OutlinedContainer(
                                  child: Text(address.municipality),
                                )
                              ],
                            ),
                            Row(
                              children: [
                                Text(
                                    'Street Address: ${address.streetAddress}\nApartment: ${address.apartment}'),
                              ],
                            ),
                          ],
                        ),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: () {
                            // delete this from list
                            _showDeleteConfirmationDialog(context, index);
                          },
                        ),
                      ),
                    ),
                  );
                },
                childCount: addressList.length,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showDeleteConfirmationDialog(
      BuildContext context, int index) async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirm Delete'),
          content: const Text('Are you sure you want to delete this address?'),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('Delete'),
              onPressed: () {
                // Delete the item from the list
                addressList.removeAt(index);
                // Close the dialog
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}

class OutlinedContainer extends StatelessWidget {
  final Widget child;
  final Color outlineColor;
  final double borderRadius;
  final double outlineWidth;

  const OutlinedContainer({
    super.key,
    required this.child,
    this.outlineColor = Colors.grey,
    this.borderRadius = 20.0,
    this.outlineWidth = 2.0,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 15),
      margin: const EdgeInsets.only(
        right: 10,
        top: 5,
        bottom: 5,
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius),
        border: Border.all(
          color: outlineColor,
          width: outlineWidth,
        ),
      ),
      child: child,
    );
  }
}
