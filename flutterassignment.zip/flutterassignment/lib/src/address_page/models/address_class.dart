import 'package:get/get.dart';

/// form data model
class AddressFormData {
  String country = '';
  String prefecture = '';
  String municipality = '';
  String streetAddress = '';
  String apartment = '';
}

/// contains all address to be used in this app
RxList<AddressFormData> addressList = [
  AddressFormData()
    ..country = 'USA'
    ..prefecture = 'New York'
    ..municipality = 'Manhattan'
    ..streetAddress = '123 Main Street'
    ..apartment = 'Apt 456',
  AddressFormData()
    ..country = 'Canada'
    ..prefecture = 'Ontario'
    ..municipality = 'Toronto'
    ..streetAddress = '456 Maple Avenue'
    ..apartment = 'Unit 789',
  // Add more AddressFormData objects as needed
].obs;
