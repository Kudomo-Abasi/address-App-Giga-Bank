import 'package:flutter/material.dart';
import 'package:flutterassignment/src/address_page/controllers/form_validators.dart';
import 'package:flutterassignment/src/address_page/models/address_class.dart';
import 'package:flutterassignment/src/address_page/screens/widgets/country_picker.dart';
import 'package:get/get.dart';

class AddressScreen extends StatefulWidget {
  final String title;
  const AddressScreen({super.key, required this.title});

  @override
  State<AddressScreen> createState() => _AddressScreenState();
}

Widget spacer() {
  return const SizedBox(height: 15);
}

class _AddressScreenState extends State<AddressScreen> {
  late GlobalKey<FormState> _formKey;
  AddressFormData addressFormData = AddressFormData();
  RxBool ready = false.obs;
  TextEditingController countryController = TextEditingController();
  TextEditingController prefectureController = TextEditingController();
  TextEditingController municipalityController = TextEditingController();
  TextEditingController streetAddressController = TextEditingController();
  TextEditingController apartmentController = TextEditingController();

  late List<TextEditingController> text = [
    countryController,
    prefectureController,
    municipalityController,
    streetAddressController,
    apartmentController
  ];

  void handleFormSubmission() {
    // store to objext
    addressFormData
      ..country = countryController.text
      ..prefecture = prefectureController.text
      ..municipality = municipalityController.text
      ..streetAddress = streetAddressController.text
      ..apartment = apartmentController.text;

    /// add to the list
    addressList.add(addressFormData);
    Get.snackbar(
      'Saved',
      'Thank you',
      colorText: Colors.black,
      backgroundColor: Colors.white,
    );

    // Debug print the form data
    debugPrint('Country: ${addressFormData.country}');
    debugPrint('Prefecture: ${addressFormData.prefecture}');
    debugPrint('Municipality: ${addressFormData.municipality}');
    debugPrint('Street Address: ${addressFormData.streetAddress}');
    debugPrint('Apartment: ${addressFormData.apartment}');
  }

  @override
  void initState() {
    super.initState();
    _formKey = GlobalKey<FormState>();

    /// note argument only comes in the form of [AddressFormData] model
    if (Get.arguments != null) {
      final AddressFormData x = Get.arguments;
      countryController.text = x.country;
      prefectureController.text = x.prefecture;
      municipalityController.text = x.municipality;
      streetAddressController.text = x.streetAddress;
      apartmentController.text = x.apartment;
    }

    /// listens for each controller and enables/disables next button
    for (var controller in text) {
      controller.addListener(() {
        ready.value = checkControllers();
      });
    }
  }

  @override
  void dispose() {
    super.dispose();

    /// listens for each controller and enables/disables next button
    for (var controller in text) {
      controller.dispose();
    }
  }

  /// used to [enable the next button].
  /// ensures that none of the controllers are empty before enabling the
  /// next button
  bool checkControllers() {
    List<TextEditingController> text = [
      countryController,
      prefectureController,
      municipalityController,
      streetAddressController,
      apartmentController
    ];
    for (int i = 0; i < text.length; i++) {
      if (text[i].text.isEmpty) {
        return false;
      }
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios),
            onPressed: () {
              Get.toNamed('/home');
            },
          ),
          title: Text(widget.title),
        ),
        body: Form(
          autovalidateMode: AutovalidateMode.onUserInteraction,
          key: _formKey,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(30.0),
              child: Column(
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          'Please enter information as written on your ID document',
                          textAlign: TextAlign.left,
                          style: Theme.of(context).textTheme.bodyLarge,
                        ),
                      ),
                    ],
                  ),
                  spacer(),
                  spacer(),
                  CountrySelector(
                    controller: countryController,
                    labelText: 'Country',
                  ),
                  spacer(),
                  TextFormField(
                    maxLines: null,
                    controller: prefectureController,
                    decoration: const InputDecoration(
                      label: Text('Prefecture'),
                    ),
                    validator: (value) {
                      return prefectureValidator(value);
                    },
                  ),
                  spacer(),
                  TextFormField(
                    maxLines: null,
                    controller: municipalityController,
                    decoration:
                        const InputDecoration(label: Text('Municipality')),
                    validator: (value) {
                      return municipalityValidator(value);
                    },
                  ),
                  spacer(),
                  TextFormField(
                      maxLines: null,
                      controller: streetAddressController,
                      decoration: const InputDecoration(
                          label: Text(
                              'Street address (subarea - block - house ..)')),
                      validator: (value) {
                        return streetAddressValidator(value);
                      }),
                  spacer(),
                  // Apartment, suite or unit
                  TextFormField(
                    maxLines: null,
                    controller: apartmentController,
                    decoration: const InputDecoration(
                        label: Text('Apartment, suite or unit')),
                    validator: (value) {
                      return apartmentValidator(value);
                    },
                  ),
                  spacer(),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.all(18.0),
          child: Obx(
            () => IntrinsicWidth(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    vertical: 22,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                        20.0), // Adjust the value as needed
                  ),
                ),
                onPressed: (ready.value)
                    ? () {
                        if (_formKey.currentState!.validate()) {
                          handleFormSubmission();
                        }
                      }
                    : null,
                child: const Text('Next'),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
