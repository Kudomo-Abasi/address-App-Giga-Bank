import 'package:flutter/material.dart';
import 'package:country_pickers/countries.dart';
import 'package:country_pickers/country.dart';
import 'package:country_pickers/country_pickers.dart';
import 'package:get/get.dart';

class CountrySelector extends StatefulWidget {
  final TextEditingController controller;
  final String labelText;

  const CountrySelector({
    required this.controller,
    super.key,
    required this.labelText,
  });

  @override
  CountrySelectorState createState() => CountrySelectorState();
}

class CountrySelectorState extends State<CountrySelector> {
  Country? _selectedCountry;

  final searchController = TextEditingController();
  List<Country> countryList2 = List.from(countryList);
  RxList<Country> filterList = RxList<Country>([]);

  @override
  void initState() {
    super.initState();
    filterList.value = List.from(countryList2);

    filterList.listen((_) {
      if (mounted) {
        setState(() {});
      }
    });
    if (widget.controller.text.isNotEmpty || widget.controller.text != "") {
      final selectedCountry = countryList2.firstWhere(
        (country) => country.name == widget.controller.text,
        orElse: () => countryList2[15],
      );

      _selectedCountry = selectedCountry;
    }

    widget.controller.addListener(() {
      final selectedCountry = countryList2.firstWhere(
        (country) => country.name == widget.controller.text,
        // orElse: () => null,
      );
      _selectedCountry = selectedCountry;
      if (mounted) {
        setState(() {});
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
    widget.controller.removeListener(() {});
  }

  void _showCountryPickerDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Select a Country'),
          content: Container(
            constraints: const BoxConstraints(maxWidth: 400, maxHeight: 700),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: searchController,
                  onChanged: (searchText) {
                    final lowercaseSearch = searchText.toLowerCase();
                    filterList.value = countryList2.where((country) {
                      final lowercaseName = country.name.toLowerCase();
                      final lowercaseCode = country.isoCode.toLowerCase();
                      return lowercaseName.contains(lowercaseSearch) ||
                          lowercaseCode.contains(lowercaseSearch);
                    }).toList();
                    if (searchText.isEmpty) {
                      filterList.value = countryList2;
                    }
                    if (mounted) {
                      setState(() {});
                    }
                  },
                  decoration: const InputDecoration(
                    labelText: 'Search Country',
                    prefixIcon: Icon(Icons.search),
                  ),
                ),
                const SizedBox(height: 10),
                Flexible(
                  child: SingleChildScrollView(
                    child: SizedBox(
                      width: double.maxFinite,
                      height: 600,
                      child: Obx(
                        () => ListView.builder(
                          itemCount: filterList.length,
                          itemBuilder: (context, index) {
                            final country = filterList[index];
                            return ListTile(
                              onTap: () {
                                widget.controller.text = country.name;
                                setState(() {});
                                Navigator.pop(
                                    context); // Close the country selector
                              },
                              leading: CountryPickerUtils.getDefaultFlagImage(
                                  country),
                              title: Text(country.name),
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(widget.labelText),
        const SizedBox(
          height: 5,
        ),
        InkWell(
          onTap: () {
            _showCountryPickerDialog(context);
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  CountryPickerUtils.getDefaultFlagImage(
                      _selectedCountry ?? countryList2[15]),
                  const SizedBox(width: 8.0),
                  Text(_selectedCountry?.name ?? 'Select Country'),
                ],
              ),
              const Column(
                children: [Icon(Icons.search)],
              )
            ],
          ),
        ),
        const Divider(),
      ],
    );
  }
}
