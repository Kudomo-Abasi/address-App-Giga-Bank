String? prefectureValidator(String? value) {
  // Check if the value is not empty
  if (value == null || value.isEmpty) {
    return 'Please enter a value';
  }
  return null;
}

String? municipalityValidator(String? value) {
  // Check if the value is not empty
  if (value == null || value.isEmpty) {
    return 'Please enter a value';
  }

  // Check if the value contains only letters and spaces
  RegExp regex = RegExp(r'^[a-zA-Z\s]*$');
  if (!regex.hasMatch(value)) {
    return 'Invalid characters. Please use only letters and spaces.';
  }
  return null;
}

String? apartmentValidator(String? value) {
  // Check if the value is not empty
  if (value == null || value.isEmpty) {
    return 'Please enter a value';
  }

  // Check if the value contains only alphanumeric characters,
  // spaces, and common address-related special characters
  RegExp regex = RegExp(r'^[a-zA-Z0-9\s\-,./#&]*$');
  if (!regex.hasMatch(value)) {
    return 'Invalid characters. Please use alphanumeric characters, spaces, and common address-related special characters.';
  }

  return null;
}

String? streetAddressValidator(String? value) {
  if (value == null || value.isEmpty) {
    return 'Please enter a value';
  }

  // Check if the value follows the "subarea-block-house" format
  // You can adjust the validation logic based on your specific requirements
  RegExp regex = RegExp(r'^\w+\s*-\s*\w+\s*-\s*\w+.*$');
  if (!regex.hasMatch(value)) {
    return 'Invalid format. Please use the subarea-block-house format. e.g: Parkside-567-House78';
  }

  return null;
}
