import 'package:flutter/material.dart';
import 'package:flutterassignment/src/address_page/screens/address_screen.dart';
import 'package:flutterassignment/src/constants/theme_data.dart';
import 'package:flutterassignment/src/home_page/screens/home_screen.dart';
import 'package:get/get.dart';

/// FEATURES:
/// Input Address Data
/// Display all inputted address in home screen
/// Validates input as requested

void main() {
  runApp(const MyApp());
}

/// TODO:
/// 1. Would need to implement some sort of
/// persistence for this app for the data
/// local or online
/// 2. implement proper save logic

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Flutter Demo',
      theme: appThemeData,
      home: const HomePage(title: 'Flutter Gigabank assignment'),
      initialRoute: '/home',
      getPages: [
        GetPage(
            name: '/home',
            page: () => const HomePage(
                  title: 'Flutter Gigabank assignment',
                ),
            transition: Transition.fade),
        GetPage(
            name: '/add-address',
            page: () => const AddressScreen(
                  title: 'Registered Address',
                ),
            transition: Transition.fade)
      ],
    );
  }
}
